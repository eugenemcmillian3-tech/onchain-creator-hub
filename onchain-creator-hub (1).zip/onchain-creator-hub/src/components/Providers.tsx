'use client'

import { WagmiProvider } from 'wagmi'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { neynar, injected } from 'wagmi/neynar'
import { http, createConfig } from 'wagmi'
import { base, baseSepolia } from 'wagmi/chains'
import { ReactNode, useState } from 'react'

// Wagmi configuration
const config = createConfig({
  chains: [base, baseSepolia],
  transports: {
    [base.id]: http(),
    [baseSepolia.id]: http(),
  },
  connectors: [
    neynar({
      options: {
        appId: process.env.NEXT_PUBLIC_NEYNAR_APP_ID || '',
        appSecret: process.env.NEXT_PUBLIC_NEYNAR_APP_SECRET || '',
      },
    }),
    injected(),
  ],
})

export function Providers({ children }: { children: ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 60 * 1000,
            refetchOnWindowFocus: false,
          },
        },
      })
  )

  return (
    <WagmiProvider config={config}>
      <QueryClientProvider client={queryClient}>
        {children}
      </QueryClientProvider>
    </WagmiProvider>
  )
}
