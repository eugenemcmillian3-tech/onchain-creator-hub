# Onchain Creator & Bounty Hub

A comprehensive Base + Farthercast dApp for creators and hunters. Built with Next.js, TypeScript, and Solidity.

## Features

- **Pay-Per-Action Frames**: Tips, paywalls, and NFT mints with automatic fee splitting
- **Creator Access Passes**: Deploy soulbound or transferable access pass NFTs
- **Escrowed Bounties**: Post bounties with funds locked in smart contracts
- **Analytics Dashboard**: Track earnings, volume, and user engagement
- **Wallet-Gated Admin Panel**: Secure platform management for owners

## Tech Stack

- **Frontend**: Next.js 14, TypeScript, TailwindCSS
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: PostgreSQL
- **Blockchain**: Base (EVM), viem/wagmi
- **Authentication**: SIWE (Sign-In with Ethereum), Neynar for Farthercast
- **Smart Contracts**: Solidity 0.8.x

## Project Structure

```
onchain-creator-hub/
├── contracts/           # Solidity smart contracts
│   └── src/
│       ├── SubscriptionManager.sol
│       ├── FeeConfig.sol
│       ├── ActionProcessor.sol
│       ├── AccessPassFactory.sol
│       └── BountyEscrow.sol
├── prisma/
│   └── schema.prisma    # Database schema
├── src/
│   ├── app/             # Next.js App Router
│   │   ├── admin/       # Admin panel pages
│   │   │   ├── config/  # Environment config
│   │   │   ├── secrets/ # Secrets management
│   │   │   ├── features/# Feature flags
│   │   │   └── health/  # System health
│   │   ├── api/         # API routes
│   │   │   ├── admin/   # Admin APIs
│   │   │   ├── auth/    # Authentication
│   │   │   ├── frame/   # Farthercast Frames
│   │   │   └── health/  # Health check
│   │   └── page.tsx     # Home page
│   ├── components/      # React components
│   └── lib/             # Utility libraries
│       ├── auth.ts      # SIWE authentication
│       ├── contracts/   # Contract addresses & ABIs
│       ├── db.ts        # Prisma client
│       ├── encryption.ts # AES-256 encryption
│       └── utils.ts     # Utility functions
├── public/
│   └── .well-known/     # Farthercast manifest
└── vercel.json          # Vercel configuration
```

## Getting Started

### Prerequisites

- Node.js 18+
- PostgreSQL database
- npm or yarn
- MetaMask or compatible wallet
- Neynar API key (for Farthercast integration)

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd onchain-creator-hub
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
```

4. Configure your `.env` file with:
   - Database URL
   - Admin wallet address
   - RPC URLs
   - API keys
   - Contract addresses

5. Set up the database:
```bash
npm run db:generate
npm run db:push
```

6. Start the development server:
```bash
npm run dev
```

## Smart Contracts

### Deploying Contracts

1. Configure your wallet private key in `.env`:
```env
PRIVATE_KEY=your-wallet-private-key
BASESCAN_API_KEY=your-basescan-api-key
```

2. Deploy to Base mainnet:
```bash
npm run contract:build
npm run contract:deploy --network baseMainnet
```

3. Update contract addresses in `.env` and redeploy the frontend.

### Contract Addresses (Base Mainnet)

After deployment, update these environment variables:
- `NEXT_PUBLIC_SUBSCRIPTION_MANAGER_ADDRESS`
- `NEXT_PUBLIC_FEE_CONFIG_ADDRESS`
- `NEXT_PUBLIC_ACTION_PROCESSOR_ADDRESS`
- `NEXT_PUBLIC_ACCESS_PASS_FACTORY_ADDRESS`
- `NEXT_PUBLIC_BOUNTY_ESCROW_ADDRESS`

## Admin Panel

### Access

The admin panel is located at `/admin` and requires:

1. Platform owner wallet connection
2. SIWE signature authentication
3. Session-based access (24-hour expiry)

### Features

- **Environment Configuration**: Manage environment variables
- **Secrets Management**: AES-256 encrypted API key storage with rotation
- **Feature Flags**: Toggle platform features and kill switches
- **System Health**: Monitor database, RPC, and API status
- **Security**: Role-enforced middleware and audit logging

### Setting Up Admin

1. Set your wallet address in `.env`:
```env
ADMIN_WALLET_ADDRESS=0xyour-wallet-address
```

2. Navigate to `/admin/login`
3. Connect your wallet
4. Sign the SIWE message to authenticate

## Farthercast Frames

### Available Frames

- **Home Frame** (`/api/frame/home`): Entry point
- **Actions Frame** (`/api/frame/actions`): Tips, paywalls, mints
- **Passes Frame** (`/api/frame/passes`): Access pass management
- **Bounties Frame** (`/api/frame/bounties`): Bounty operations
- **Analytics Frame** (`/api/frame/analytics`): Stats and insights

### Frame Validation

Frames are validated using Neynar's frame validation API. Configure your API key in environment variables.

## Pricing

### Subscription Tiers

| Tier | Price | Monthly Volume | Features |
|------|-------|----------------|----------|
| Starter | $9/mo | $500 | 1 pass collection, basic analytics |
| Pro | $29/mo | $10K | 5 pass collections, advanced analytics |
| Power | $99/mo | $100K | Unlimited, full API access |

### Pay-Per-Use

For non-subscribers:
- Pay-per-action: $0.25/transaction
- Platform fees: 7.5-10% on sales

## Security

### Encryption

All secrets are encrypted using AES-256-CBC before storage. The encryption key is stored in environment variables.

### Authentication

- SIWE (Sign-In with Ethereum) for admin access
- Nonce-based signature verification
- Session cookies with httpOnly flag

### Rate Limiting

API rate limiting is enabled by default. Configure limits in environment variables.

## Development

### Database Commands

```bash
# Generate Prisma client
npm run db:generate

# Push schema changes
npm run db:push

# Run migrations
npm run db:migrate

# Open Prisma Studio
npm run db:studio
```

### Testing Frames

Use the [Farthercast Developer Playground](https://warpcast.com/~/developers/frames) to test frames locally with ngrok.

## Deployment

### Vercel (Recommended)

1. Connect your repository to Vercel
2. Configure environment variables in Vercel dashboard
3. Deploy

### Docker

```bash
docker build -t onchain-creator-hub .
docker run -p 3000:3000 onchain-creator-hub
```

### Environment Variables for Production

Ensure all sensitive variables are set:
- `DATABASE_URL` - Production PostgreSQL
- `NEXTAUTH_SECRET` - Strong random string (32+ chars)
- `SECRET_ENCRYPTION_KEY` - 64-character hex string
- `ADMIN_WALLET_ADDRESS` - Platform owner wallet
- `BASE_RPC_URL` - Production Base RPC
- Contract addresses for all deployed contracts

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## License

MIT License - see LICENSE file for details.

## Disclaimer

This platform sells tools, access, and coordination only. Not investment advice. Use at your own risk.
